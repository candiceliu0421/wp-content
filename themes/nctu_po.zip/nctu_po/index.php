<?php get_template_part('includes/header'); ?>

<div class="container">
  <div class="row">
    這是首頁模板
  </div><!-- /.row -->
</div><!-- /.container -->

<?php get_template_part('includes/footer'); ?>
