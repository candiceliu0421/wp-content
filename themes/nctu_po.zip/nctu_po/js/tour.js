// nav hover 展開2個直角梯形
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox1').show();
    }, function () {
        $(this).find('div.navbox1').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox1_2').show();
    }, function () {
        $(this).find('div.navbox1_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox2').show();
    }, function () {
        $(this).find('div.navbox2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox2_2').show();
    }, function () {
        $(this).find('div.navbox2_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox3').show();
    }, function () {
        $(this).find('div.navbox3').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox3_2').show();
    }, function () {
        $(this).find('div.navbox3_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox4').show();
    }, function () {
        $(this).find('div.navbox4').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox4_2').show();
    }, function () {
        $(this).find('div.navbox4_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox5').show();
    }, function () {
        $(this).find('div.navbox5').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox5_2').show();
    }, function () {
        $(this).find('div.navbox5_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox6').show();
    }, function () {
        $(this).find('div.navbox6').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox6_2').show();
    }, function () {
        $(this).find('div.navbox6_2').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox7').show();
    }, function () {
        $(this).find('div.navbox7').hide();
    });
});
$(document).ready(function () {
    $('div.top').hover(function () {
        $(this).find('div.navbox7_2').show();
    }, function () {
        $(this).find('div.navbox7_2').hide();
    });
});

// $(document).ready(function(){
//     $("#navboxw1_3").click(function(){
//         $("div.navbox1_3").toggle();
//     });


// jQuery(document).ready(function () {
//     jQuery(".navbox1_3").hide(); //hide at the beginning

//     function hideDiv(e) {
//         e.preventDefault();
//         jQuery(this).text('本 室 簡 介')
//         .click(showDiv)
//         .siblings(".navbox1_3").hide()
//     }
//     function showDiv(e) {
//         e.preventDefault();
//         jQuery(this).text('本 室 簡 介')
//         .click(hideDiv)
//         .siblings(".navbox1_3").show()
//     }
//     jQuery('#navboxw1_2_1').click( showDiv );
// });

// jQuery(document).ready(function () {
//     jQuery(".navbox1_4").hide(); //hide at the beginning

//     function hideDiv(e) {
//         e.preventDefault();
//         jQuery(this).text('本 室 簡 介')
//         .click(showDiv)
//         .siblings(".navbox1_4").hide()
//     }
//     function showDiv(e) {
//         e.preventDefault();
//         jQuery(this).text('本 室 簡 介')
//         .click(hideDiv)
//         .siblings(".navbox1_4").show()
//     }
//     jQuery('#navboxw1_2_1').click( showDiv );
// });